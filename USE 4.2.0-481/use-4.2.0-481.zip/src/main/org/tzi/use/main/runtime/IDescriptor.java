package org.tzi.use.main.runtime;

/**
 * Base interface for all Descriptor Classes - this interface should only be
 * used internally
 * 
 * @author Roman Asendorf
 */

public interface IDescriptor {

}
