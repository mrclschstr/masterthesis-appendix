# Additional notes

This copy of the USE tool contains the following aspects and changes:

- USE version use-4.2.0-481 from [Jenkins](http://ci.db.informatik.uni-bremen.de:8080/job/USE%20Trunk/481/).
- Model Validator Plugin build 5628 from [Jenkins](http://ci.db.informatik.uni-bremen.de:8080/job/Model%20Validator%20Trunk/5628/).
- SAT-solvers for KodKod 2.0 (both Windows/Linux and 32/64 Bit) from [KodKod Homepage](https://emina.github.io/kodkod/old.html).
- Changes in [ObjectNode.java](/src/gui/org/tzi/use/gui/views/diagrams/objectdiagram/ObjectNode.java#L217) (line 217 to 238) for shortened display of large sets in object diagrams incl. recompiling of Java class files.
- Compiling of `natGNUReadline.c` for Linux 64 Bit operating systems (Ubuntu).
- OCL extension [BitOperations.xml](/oclextensions/BitOperations.xml) added for the use of binary-and within USE.
- Modified default [configuration](/lib/plugins/modelValidatorPlugin/mv.ini) of MV Plugin: `bitwidth = 13`, `satsolver = minisat` and `objExtraction = off`.
